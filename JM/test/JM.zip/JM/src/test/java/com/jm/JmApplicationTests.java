package com.jm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JmApplicationTests {

	@Test
	void contextLoads() {
	}

}
